import tkinter as tk
from tkinter import ttk, messagebox
import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import quad
from scipy.optimize import fsolve

#Inicio de la clase
class SolidoRevolucionApp:
    #Constructor parametrizado
    def __init__(self, ventana_principal):
        self.root = ventana_principal
        self.root.title("Analizador de Sólidos de Revolución")
        self.root.geometry("450x350")
        self.root.resizable(False, False)

        #Construye los margenes
        self.frame = ttk.Frame(self.root, padding="20")
        self.frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        self.crear_componentes()
#Funcion para crear la interfaz grafica
    def crear_componentes(self):
        #Crea el menu desplegable
        #Recibe las entradas del usuario
        ttk.Label(self.frame, text="Función Superior f(x):").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.txt_func1 = ttk.Entry(self.frame, width=30)
        self.txt_func1.grid(row=0, column=1, pady=5)
        self.txt_func1.insert(0, "4")

        ttk.Label(self.frame, text="Función Inferior g(x):").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.txt_func2 = ttk.Entry(self.frame, width=30)
        self.txt_func2.grid(row=1, column=1, pady=5)
        self.txt_func2.insert(0, "x^2")

        #Ejes de giro
        ttk.Label(self.frame, text="Orientación del Eje:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.cbo_eje = ttk.Combobox(self.frame, values=["Horizontal (Y = k)", "Vertical (X = k)"], state="readonly",
                                    width=27)
        self.cbo_eje.grid(row=2, column=1, pady=5)
        self.cbo_eje.current(0)

        ttk.Label(self.frame, text="Valor de la constante (k):").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.txt_k = ttk.Entry(self.frame, width=30)
        self.txt_k.grid(row=3, column=1, pady=5)
        self.txt_k.insert(0, "6")

        #Botón para graficar y calcular
        self.btn_procesar = ttk.Button(self.frame, text="Calcular y Graficar 3D", command=self.procesar_sistema)
        self.btn_procesar.grid(row=4, column=0, columnspan=2, pady=20, ipadx=10)

        #Resultados Salidas al usuario
        self.lbl_limites = ttk.Label(self.frame, text="Límites calculados: Ninguno", font=('Arial', 9, 'italic'))
        self.lbl_limites.grid(row=5, column=0, columnspan=2, sticky=tk.W, pady=2)

        self.lbl_volumen = ttk.Label(self.frame, text="Volumen Resultante: 0.0000 u³", font=('Arial', 10, 'bold'))
        self.lbl_volumen.grid(row=6, column=0, columnspan=2, sticky=tk.W, pady=5)

#Logica matematica para calcular solidos
    def parsing_matematico(self, texto_usuario):
        #Cambia el texto ingresado a valores numericos
        cadena = texto_usuario.lower().replace('y=', '').replace('y =', '').replace('^', '**')
        #Operadores de la libreria numpy
        for palabra in ['sin', 'cos', 'tan', 'exp', 'sqrt', 'pi']:
            cadena = cadena.replace(palabra, f'np.{palabra}')

        def funcion_evaluada(x):
            resultado = eval(cadena, {"np": np, "x": x})
            #Crea el arreglo para graficar
            if isinstance(x, np.ndarray) and not isinstance(resultado, np.ndarray):
                return np.full_like(x, resultado)
            return resultado

        return funcion_evaluada
#busca las intersecciones para determinar los limites de integracion
    def localizar_intersecciones(self, f1, f2):
        #Busca los valores de interseccion mediante la igualacion de las funciones
        muestreo_x = np.linspace(-20, 20, 2000)
        diferencial_y = f1(muestreo_x) - f2(muestreo_x)

        #detecta los cambios de signo en los valores obtenidos
        cruces = np.where(np.diff(np.sign(diferencial_y)) != 0)[0]
        puntos_raiz = []

        for idx in cruces:
            #Resuelve la resta de funciones f1(x) - f2(x) = 0 usando aproximación numérica
            raiz, = fsolve(lambda x: f1(x) - f2(x), muestreo_x[idx])
            if not any(np.isclose(puntos_raiz, raiz, atol=1e-4)):
                puntos_raiz.append(raiz)

        puntos_raiz.sort()
        if len(puntos_raiz) < 2:
            raise ValueError("Las curvas no se encierran o no tienen suficientes intersecciones.")
        return puntos_raiz[0], puntos_raiz[-1]

    def procesar_sistema(self):
        #Se encarga de la creacion de los graficos en 3d
        try:
            #Recupera las funciones
            f1 = self.parsing_matematico(self.txt_func1.get())
            f2 = self.parsing_matematico(self.txt_func2.get())
            cte_k = float(self.txt_k.get())
            es_horizontal = "Horizontal" in self.cbo_eje.get()

            #Encuentra los limites de integracion de la funcion
            lim_a, lim_b = self.localizar_intersecciones(f1, f2)
            self.lbl_limites.config(text=f"Límites calculados: a = {lim_a:.4f}, b = {lim_b:.4f}")

            #Integra dependiendo el eje de rotacion
            if es_horizontal:
                #Arandelas
                def integrando_h(x):
                    return abs((f1(x) - cte_k) ** 2 - (f2(x) - cte_k) ** 2)

                area_total, _ = quad(integrando_h, lim_a, lim_b)
                volumen_final = np.pi * area_total
            else:
                #Cascarones
                def integrando_v(x):
                    return 2 * np.pi * abs(x - cte_k) * abs(f1(x) - f2(x))

                volumen_final, _ = quad(integrando_v, lim_a, lim_b)

            self.lbl_volumen.config(text=f"Volumen Resultante: {volumen_final:.4f} u³")

            #Grafiica el solido con Matplotlib
            self.graficar_solido(f1, f2, lim_a, lim_b, cte_k, es_horizontal)

        except Exception as e:
            messagebox.showerror("Fallo en Proceso", f"Ocurrió un error en el cálculo:\n{str(e)}")

    def graficar_solido(self, f1, f2, a, b, k, es_horizontal):
        #Comienza a generar el solido con la configuracion de ejes y mallas
        fig = plt.figure("Visualización de Sólido 3D - Proyecto")
        ax = fig.add_subplot(111, projection='3d')

        puntos_lineal_x = np.linspace(a, b, 100)
        angulos_rotacion = np.linspace(0, 2 * np.pi, 60)
        Malla_X, Malla_Theta = np.meshgrid(puntos_lineal_x, angulos_rotacion)

        Capa1_Y = np.tile(f1(puntos_lineal_x), (60, 1))
        Capa2_Y = np.tile(f2(puntos_lineal_x), (60, 1))

        if es_horizontal:
            #Rotación sobre un eje paralelo al eje X
            Z1, Y1 = abs(Capa1_Y - k) * np.sin(Malla_Theta), k + abs(Capa1_Y - k) * np.cos(Malla_Theta)
            Z2, Y2 = abs(Capa2_Y - k) * np.sin(Malla_Theta), k + abs(Capa2_Y - k) * np.cos(Malla_Theta)
            X1 = X2 = Malla_X
            ax.plot([a, b], [k, k], [0, 0], color='black', linestyle='--', linewidth=2, label=f'Eje Y = {k}')
        else:
            #Rotación sobre un eje paralelo al eje Y
            Z1, X1 = abs(Malla_X - k) * np.sin(Malla_Theta), k + abs(Malla_X - k) * np.cos(Malla_Theta)
            Z2, X2 = abs(Malla_X - k) * np.sin(Malla_Theta), k + abs(Malla_X - k) * np.cos(Malla_Theta)
            Y1, Y2 = Capa1_Y, Capa2_Y
            limites_y = np.concatenate([f1(puntos_lineal_x), f2(puntos_lineal_x)])
            ax.plot([k, k], [limites_y.min(), limites_y.max()], [0, 0], color='black', linestyle='--', linewidth=2,
                    label=f'Eje X = {k}')

        #Crea las mallas de los ejes con transparencias
        ax.plot_surface(X1, Y1, Z1, color='royalblue', alpha=0.4, edgecolor='none')
        ax.plot_surface(X2, Y2, Z2, color='crimson', alpha=0.7, edgecolor='none')

        ax.set_xlabel('Eje X')
        ax.set_ylabel('Eje Y')
        ax.set_zlabel('Eje Z')
        ax.set_title("Sólido de Revolución Generado")
        plt.show()


if __name__ == "__main__":
    ventana = tk.Tk()
    app = SolidoRevolucionApp(ventana)
    ventana.mainloop()